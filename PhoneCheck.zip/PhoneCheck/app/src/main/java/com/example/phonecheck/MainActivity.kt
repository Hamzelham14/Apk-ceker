package com.example.phonecheck

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.URI

@Suppress("DEPRECATION")
class MainActivity : Activity() {

    // Toko aplikasi resmi. Aplikasi yang dipasang dari luar ini dianggap "sideload".
    private val trustedStores = setOf(
        "com.android.vending", "com.sec.android.app.samsungapps", "com.huawei.appmarket",
        "com.xiaomi.mipicks", "com.heytap.market", "com.vivo.appstore", "com.amazon.venezia"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 3, pad, pad * 2)
        }
        fun tv(t: String, size: Float = 15f) = TextView(this).apply {
            text = t; textSize = size; setTextIsSelectable(true)
        }

        val btnScan = Button(this).apply { text = "Pindai aplikasi & pengaturan" }
        val outScan = tv("")
        val etUrl = EditText(this).apply {
            hint = "Tempel link yang dicurigai"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
        }
        val btnUrl = Button(this).apply { text = "Cek link phishing" }
        val outUrl = tv("")

        btnScan.setOnClickListener {
            outScan.text = "Memindai..."
            Thread {
                val r = try { scan() } catch (e: Exception) { "Gagal memindai: ${e.message}" }
                runOnUiThread { outScan.text = r }
            }.start()
        }
        btnUrl.setOnClickListener { outUrl.text = analyzeUrl(etUrl.text.toString()) }

        listOf(
            tv("Phone Check", 26f),
            tv("Pemindai sederhana & offline (heuristik). Bukan pengganti antivirus / Play Protect."),
            btnScan, outScan, tv(""), etUrl, btnUrl, outUrl
        ).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    // ---------------------------------------------------------------- helpers

    private fun isSystem(pkg: String): Boolean = try {
        (packageManager.getApplicationInfo(pkg, 0).flags and ApplicationInfo.FLAG_SYSTEM) != 0
    } catch (e: Exception) { false }

    private fun appName(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private fun installerOf(pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) packageManager.getInstallSourceInfo(pkg).installingPackageName
        else packageManager.getInstallerPackageName(pkg)
    } catch (e: Exception) { null }

    private fun installed(): List<PackageInfo> =
        if (Build.VERSION.SDK_INT >= 33)
            packageManager.getInstalledPackages(
                PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong())
            )
        else packageManager.getInstalledPackages(PackageManager.GET_PERMISSIONS)

    private fun enabledPkgs(key: String): List<String> =
        (Settings.Secure.getString(contentResolver, key) ?: "")
            .split(":").filter { it.contains("/") }.map { it.substringBefore("/") }
            .distinct().filter { it != packageName && !isSystem(it) }

    // ---------------------------------------------------------------- scan aplikasi

    private fun scan(): String {
        val high = StringBuilder()
        val mid = StringBuilder()
        var total = 0

        for (p in installed()) {
            val ai = p.applicationInfo ?: continue
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 || p.packageName == packageName) continue
            total++

            val perms = p.requestedPermissions?.toSet() ?: emptySet()
            val inst = installerOf(p.packageName)
            var score = 0
            val why = mutableListOf<String>()

            if (inst == null || inst !in trustedStores) { score += 2; why += "bukan dari toko resmi" }
            if ("android.permission.READ_SMS" in perms || "android.permission.RECEIVE_SMS" in perms) {
                score += 2; why += "bisa baca SMS/OTP"
            }
            if ("android.permission.SYSTEM_ALERT_WINDOW" in perms) { score += 1; why += "bisa menimpa layar (overlay)" }
            if ("android.permission.REQUEST_INSTALL_PACKAGES" in perms) { score += 1; why += "bisa memasang APK lain" }
            if ("android.permission.READ_CALL_LOG" in perms) { score += 1; why += "baca riwayat panggilan" }

            val line = "- ${appName(p.packageName)} (${p.packageName})\n   ${why.joinToString(", ")}\n"
            when {
                score >= 4 -> high.append(line)
                score >= 2 -> mid.append(line)
            }
        }

        val sb = StringBuilder("Aplikasi non-sistem diperiksa: $total\n\n")
        sb.append(if (high.isEmpty()) "RISIKO TINGGI: tidak ada\n\n" else "RISIKO TINGGI:\n$high\n")
        sb.append(if (mid.isEmpty()) "PERLU DICEK: tidak ada\n\n" else "PERLU DICEK:\n$mid\n")

        // Pengaturan yang sering disalahgunakan malware
        val acc = enabledPkgs(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        val notif = enabledPkgs("enabled_notification_listeners")
        val admins = try {
            (getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager).activeAdmins
                ?.map { it.packageName }?.filter { it != packageName && !isSystem(it) } ?: emptyList()
        } catch (e: Exception) { emptyList() }
        val adb = Settings.Global.getInt(contentResolver, Settings.Global.ADB_ENABLED, 0) == 1

        sb.append("PENGATURAN SENSITIF:\n")
        sb.append("- Aksesibilitas aktif: ${fmt(acc)}\n")
        sb.append("- Akses baca notifikasi: ${fmt(notif)}\n")
        sb.append("- Admin perangkat: ${fmt(admins)}\n")
        sb.append("- USB debugging: ${if (adb) "AKTIF" else "mati"}\n\n")
        sb.append(
            "Catatan: Aksesibilitas, akses notifikasi, dan admin perangkat adalah cara umum malware " +
            "mencuri OTP dan mengendalikan HP. Matikan di Pengaturan jika kamu tidak mengenali aplikasinya."
        )
        return sb.toString()
    }

    private fun fmt(pkgs: List<String>) =
        if (pkgs.isEmpty()) "tidak ada" else pkgs.joinToString(", ") { appName(it) }

    // ---------------------------------------------------------------- cek link phishing

    private val official = mapOf(
        "bca" to listOf("bca.co.id", "klikbca.com"), "bri" to listOf("bri.co.id"),
        "bni" to listOf("bni.co.id"), "mandiri" to listOf("bankmandiri.co.id", "mandiri.co.id"),
        "dana" to listOf("dana.id"), "ovo" to listOf("ovo.id"),
        "gopay" to listOf("gopay.co.id", "gojek.com"), "shopee" to listOf("shopee.co.id", "shopee.com"),
        "tokopedia" to listOf("tokopedia.com"), "google" to listOf("google.com", "google.co.id"),
        "facebook" to listOf("facebook.com", "fb.com"), "instagram" to listOf("instagram.com"),
        "whatsapp" to listOf("whatsapp.com", "wa.me"), "paypal" to listOf("paypal.com"),
        "apple" to listOf("apple.com", "icloud.com"), "microsoft" to listOf("microsoft.com", "live.com"),
        "netflix" to listOf("netflix.com"), "tiktok" to listOf("tiktok.com"),
        "bpjs" to listOf("bpjs-kesehatan.go.id", "bpjsketenagakerjaan.go.id")
    )
    private val shorteners = setOf(
        "bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly", "s.id", "rebrand.ly", "shorturl.at", "t.ly"
    )
    private val badTlds = setOf("xyz", "top", "click", "gq", "tk", "ml", "cf", "ga", "icu", "cyou", "zip", "mov", "work", "rest")
    private val keywords = listOf(
        "login", "verify", "verifikasi", "update", "secure", "akun", "blokir",
        "hadiah", "undian", "klaim", "otp", "pemenang", "gratis", "konfirmasi"
    )

    private fun regDomain(host: String): String {
        val l = host.split('.')
        if (l.size <= 2) return host
        val second = l[l.size - 2]
        val n = if (l.last().length == 2 && second in setOf("co", "com", "or", "go", "ac", "net", "web", "my", "sch")) 3 else 2
        return l.takeLast(n).joinToString(".")
    }

    private fun analyzeUrl(input: String): String {
        var s = input.trim()
        if (s.isEmpty()) return "Tempel link dulu."
        val hasScheme = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://").containsMatchIn(s)
        if (!hasScheme) s = "https://$s"

        val bad = "Format link tidak wajar. Jangan dibuka."
        val uri = try { URI(s) } catch (e: Exception) { return bad }
        val host = (uri.host ?: return bad).lowercase()

        var score = 0
        val r = mutableListOf<String>()
        fun add(p: Int, t: String) { score += p; r += t }

        if (hasScheme && uri.scheme.equals("http", true)) add(1, "tidak memakai HTTPS")
        if (Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(host)) add(3, "memakai alamat IP, bukan nama domain")
        if (uri.userInfo != null) add(3, "ada tanda @ yang menyamarkan tujuan asli")
        if (host.startsWith("xn--") || host.contains(".xn--")) add(2, "domain punycode (bisa menyamar mirip huruf lain)")
        if (host in shorteners) add(2, "link pendek, tujuan asli tersembunyi")
        if (host.substringAfterLast('.') in badTlds) add(1, "ekstensi domain yang sering dipakai penipuan")
        if (host.split('.').size >= 5) add(1, "terlalu banyak subdomain")
        if (host.count { it == '-' } >= 3) add(1, "banyak tanda hubung di nama domain")
        if (s.length > 75) add(1, "link sangat panjang")
        if (uri.path?.lowercase()?.endsWith(".apk") == true) add(3, "mengunduh file APK")

        val reg = regDomain(host)
        val tokens = host.split('.', '-')
        for ((brand, domains) in official) {
            if (brand in tokens && reg !in domains) {
                add(3, "memakai nama \"$brand\" tapi domain resminya bukan ini"); break
            }
        }
        val hits = keywords.filter { it in s.lowercase() }
        if (hits.isNotEmpty()) add(1, "kata pancingan: ${hits.joinToString(", ")}")

        val verdict = when {
            score >= 4 -> "SANGAT MENCURIGAKAN. Jangan dibuka atau isi data apa pun."
            score >= 2 -> "MENCURIGAKAN. Pastikan lewat aplikasi/situs resmi."
            else -> "Tidak ada tanda jelas. Ini bukan jaminan aman."
        }
        val detail = if (r.isEmpty()) "" else "\n\n" + r.joinToString("\n") { "- $it" }
        return "$verdict\nDomain: $host$detail"
    }
}
